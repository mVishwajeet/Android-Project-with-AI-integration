# == Schema Information
#
# Table name: cupcakes
#
#  id         :bigint           not null, primary key
#  image      :string
#  title      :string
#  created_at :datetime         not null
#  updated_at :datetime         not null
#
require "test_helper"

class CupcakeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
