class PagesController < ApplicationController

    def home
        @cupcakes = Cupcake.all
        render :home
    end

    def blog 
       @cupcake = Cupcake.find(params[:cupcake_id])
       @blog = @cupcake.blogs
        render :blog
    end

end
