# == Schema Information
#
# Table name: blogs
#
#  id          :bigint           not null, primary key
#  description :string
#  image       :string
#  title       :string
#  created_at  :datetime         not null
#  updated_at  :datetime         not null
#  cupcake_id  :bigint
#
# Indexes
#
#  index_blogs_on_cupcake_id  (cupcake_id)
#
# Foreign Keys
#
#  fk_rails_...  (cupcake_id => cupcakes.id)
#
class Blog < ApplicationRecord

    belongs_to(
        :cupcake,
        class_name: 'Cupcake',
        foreign_key: 'cupcake_id',
        inverse_of: :blogs
    )

end
