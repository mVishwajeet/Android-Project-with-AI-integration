# == Schema Information
#
# Table name: cupcakes
#
#  id         :bigint           not null, primary key
#  image      :string
#  title      :string
#  created_at :datetime         not null
#  updated_at :datetime         not null
#
class Cupcake < ApplicationRecord

    has_one(
        :blogs,
        class_name: 'Blog',
        foreign_key: 'cupcake_id',
        inverse_of: :cupcake,
        dependent: :destroy
    )

end
