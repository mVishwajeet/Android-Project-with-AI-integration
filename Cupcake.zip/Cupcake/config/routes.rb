Rails.application.routes.draw do
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html
  get 'home', to: 'pages#home', as: 'home'
  get 'home/:cupcake_id', to: 'pages#blog', as: 'blog'
  # Defines the root path route ("/")
  # root "articles#index"
end
