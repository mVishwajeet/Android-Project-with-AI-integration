Rails.application.config.assets.paths += Gem.loaded_specs['bootswatch'].load_paths
