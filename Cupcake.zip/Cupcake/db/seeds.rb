# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the bin/rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: "Star Wars" }, { name: "Lord of the Rings" }])
#   Character.create(name: "Luke", movie: movies.first)

cp1 = Cupcake.create!(
    title: 'first',
    image: 'vanilla-1.jpeg'
)

cp2 = Cupcake.create!(
    title: 'second',
    image: 'raspberry-1.jpeg'
)

b1 = Blog.create!(
    title: 'first',
    image: 'vanilla-1.jpeg',
    description: '
    Vanilla Cupcake:
    Blog:
    This is m absolute favorite vanilla cupcake recipe! It yields light, fluffy, moist cupcakes that
    dome perfectly, and you can really taste the vanilla in every bite.
    While this recipe is used by bakeries all over the world, it is easy enough to make that a
    beginner can whip up a batch.
    Ingredients
    A vanilla bean
    Both butter and oil
    Sour cream
    Cake Flour
    Eggs
    Milk
    Recipe:
    Step1: Preheat your oven to 350 F before beginning.
    Step2: scrape the inside of a vanilla bean (the seeds) into sugar and thoroughly mix everything
    up. Using this vanilla sugar will give the cupcakes a strong flavor and you will end up with visually
    appealing vanilla bean specks all over!
    Note: Using a real vanilla bean adds both flavor and visual appeal to the vanilla cupcakes.
    Step3: Whisk together the vanilla sugar with the rest of the dry ingredients (cake flour, baking
    powder, baking soda, and salt) in the bowl of a stand mixer. If you do not have a stand mixer,
    you can use an electric hand mixer or even mix by hand and always mix dry ingredients
    together thoroughly.
    Tip: If you do not have cake flour, you can substitute all-purpose flour in equal amounts; the
    cupcakes will end up a little bit denser. Cake flour is a finely milled delicate flour and it is best
    for desserts that are lighter and airier.
    Step4: Mix in the butter.
    Note: Using a stand mixer is the easiest way to make the best vanilla cupcakes.
    Step5: Whisk together the wet ingredients in a separate bowl. These include sour cream, oil,
    eggs, and vanilla extract.
    Note: These vanilla cupcakes get more moisture and a nice tang from the addition of sour
    cream.
    Step6: Mix wet ingredients into dry ingredients.
    Tip: It is very important to not over-mix the batter at this point. Mix until just combined. A
    cupcake with an over-mixed batter will end up squat and dense  something you do not want
    here.
    Mixing until just combined makes vanilla cupcakes rise and dome perfectly.
    Step7: Add milk to the batter, again mixing until just combined. This cupcake batter is very thin
     almost liquid.
    Tip: While whole milk will provide the richest flavor, any milk you have in the house will work
    fine.
    Note: Vanilla cupcakes taste best when the batter is thinned out with whole milk.
    Step8: Fill liners just over halfway full. The easiest way to fill the liners is with an ice cream
    scoop. Bake for 14 minutes or until done. You can check for doneness by inserting a toothpick
    into the center of a cupcake; it should come out dry to indicate doneness.
    Step9: Remove the cupcakes from the tins immediately and set on the counter or a cooling rack
    to cool.
     ',
    cupcake: cp1
)

b2 = Blog.create!(
    title: 'Second',
    image: 'raspberry-1.jpeg',
    description: '
    Vanilla Cupcake:
    Blog:
    This is my absolute favorite vanilla cupcake recipe! It yields light, fluffy, moist cupcakes that
    dome perfectly, and you can really taste the vanilla in every bite.
    While this recipe is used by bakeries all over the world, it is easy enough to make that a
    beginner can whip up a batch.
    Ingredients
    A vanilla bean
    Both butter and oil
    Sour cream
    Cake Flour
    Eggs
    Milk
    Recipe:
    Step1: Preheat your oven to 350 F before beginning.
    Step2: scrape the inside of a vanilla bean (the seeds) into sugar and thoroughly mix everything
    up. Using this vanilla sugar will give the cupcakes a strong flavor and you will end up with visually
    appealing vanilla bean specks all over!
    Note: Using a real vanilla bean adds both flavor and visual appeal to the vanilla cupcakes.
    Step3: Whisk together the vanilla sugar with the rest of the dry ingredients (cake flour, baking
    powder, baking soda, and salt) in the bowl of a stand mixer. If you do not have a stand mixer,
    you can use an electric hand mixer or even mix by hand and always mix dry ingredients
    together thoroughly.
    Tip: If you do not have cake flour, you can substitute all-purpose flour in equal amounts; the
    cupcakes will end up a little bit denser. Cake flour is a finely milled delicate flour and it is best
    for desserts that are lighter and airier.
    Step4: Mix in the butter.
    Note: Using a stand mixer is the easiest way to make the best vanilla cupcakes.
    Step5: Whisk together the wet ingredients in a separate bowl. These include sour cream, oil,
    eggs, and vanilla extract.
    Note: These vanilla cupcakes get more moisture and a nice tang from the addition of sour
    cream.
    Step6: Mix wet ingredients into dry ingredients.
    Tip: It is very important to not over-mix the batter at this point. Mix until just combined. A
    cupcake with an over-mixed batter will end up squat and dense  something you do not want
    here.
    Mixing until just combined makes vanilla cupcakes rise and dome perfectly.
    Step7: Add milk to the batter, again mixing until just combined. This cupcake batter is very thin
     almost liquid.
    Tip: While whole milk will provide the richest flavor, any milk you have in the house will work
    fine.
    Note: Vanilla cupcakes taste best when the batter is thinned out with whole milk.
    Step8: Fill liners just over halfway full. The easiest way to fill the liners is with an ice cream
    scoop. Bake for 14 minutes or until done. You can check for doneness by inserting a toothpick
    into the center of a cupcake; it should come out dry to indicate doneness.
    Step9: Remove the cupcakes from the tins immediately and set on the counter or a cooling rack
    to cool.
     ',
    cupcake: cp2
)